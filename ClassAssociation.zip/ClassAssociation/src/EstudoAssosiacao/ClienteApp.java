package EstudoAssosiacao;

public class ClienteApp {

    public static void main(String[] args) {

         Endereco endereco1 = new Endereco (4582256,"Rua das taltl tal ");
         Cliente cliente1 = new Cliente(45896232,"Alejandro",endereco1);

         Endereco obterendereco = cliente1.getEndereco();
         System.out.println("o cep do cliente: "+obterendereco.getCep());


    }

}
