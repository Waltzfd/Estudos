package EstudoAssosiacao;

public class Endereco {

    private int cep;
    private String nomeRua;

    public Endereco(int cep, String nomeRua) {
        this.cep = cep;
        this.nomeRua = nomeRua;
    }

    public int getCep() {
        return cep;
    }

    public void setCep(int cep) {
        this.cep = cep;
    }

    public String getNomeRua() {
        return nomeRua;
    }

    public void setNomeRua(String nomeRua) {
        this.nomeRua = nomeRua;
    }
}


