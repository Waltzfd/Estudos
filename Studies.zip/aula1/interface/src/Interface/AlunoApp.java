package Interface;

public class AlunoApp {

    public static void main(String[] args) {

        Aluno aluno1 = new Aluno ("jorge", "Rua tal tal tal tal tal tal ", 7.2,9.4);
         aluno1.calcularMedia();

         Aluno aluno2 = new Aluno ( "Renato", "Rua isso isso e aquilo", 6.0, 3.4);
         aluno2.calcularMedia();

         System.out.println("O Aluno foi: "+ aluno1.verificarAprovacao());
         System.out.println("O aluno foi: "+aluno2.verificarAprovacao());



    }



}


