package Interface;

public interface SituacaoAcademica {

    public String verificarAprovacao();
    public double calcularMedia();

}
