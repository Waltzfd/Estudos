package aula2;

public class ClientApp {

 public static void main(String[] args) {

      CPF clientepf = new CPF("Alessandro"," rua tal tal tal "," 884422666");
      cnpj clientepj = new cnpj("Diogo", " Rua tal de tal tal "," 556662244");

      //System.out.println("Os dados do Clientepf: "+clientepf.getNome()+clientepf.getEndereco()+clientepf.getCpf() );
      //System.out.println("Os dados do Clientepj: "+clientepj.getNome()+clientepj.getEndereco()+ clientepj.getCnpj());

        System.out.println(clientepj.toString());
        System.out.println(clientepf.toString());
 }
}