package aula2;

public class cnpj extends Cliente {

    private String cnpj;

    public cnpj(String nome, String endereco, String cnpj) {
        super(nome, endereco);
        this.cnpj = cnpj;
    }

    public String getCnpj() {
        return cnpj;
    }

    public void setCnpj(String cnpj) {
        this.cnpj = cnpj;
    }

    public String toString() {
        return super.toString()+"CNPJ"+ cnpj;
    }
}
