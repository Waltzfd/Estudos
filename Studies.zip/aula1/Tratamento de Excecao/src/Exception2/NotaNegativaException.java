package Exception2;

public class NotaNegativaException extends Exception {

    //
    public NotaNegativaException(){
        System.out.println("Não Existe nota negativa");

        //
    }
}
