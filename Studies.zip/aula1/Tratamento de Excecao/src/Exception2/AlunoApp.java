package Exception2;

import java.io.NotActiveException;

public class AlunoApp {
    public static void main(String[] args) {

        Aluno aluno1 = new Aluno (10.0, 8.0);
        Aluno aluno2 = new Aluno(10.0,-6.0);


        try {
            //aluno1.validaNota();
            aluno2.validaNota();
        }

      catch (NotaNegativaException nne){
            System.out.println(nne.getMessage());
      }
        }

    }
