package Exception;

public class ErroApp {
    public static void main(String[] args) {

        int valor1,valor2;
        float resultado;

        valor1=10;
        valor2=0;

       try {
        resultado = valor1/valor2;
         System.out.println("O valor foi: "+resultado);
       }
       catch (ArithmeticException ae){
           System.out.println("Erro, número não pode ser divido");

       }
    finally {
           System.out.println("Sou executado sempre");
       }

    }
}
