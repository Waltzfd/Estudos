package aula1;

public class PessoaApp {
    public static void main(String[] args) {

        Pessoa pessoa1 = new Pessoa(1, "Mota");
        Pessoa pessoa2 = new Pessoa(2, "Claudio");

        System.out.println("O nome da pessoa é " + pessoa1.getCode() + pessoa1.getName());
        System.out.println("O nome da pessoa é " + pessoa1.getCode() + pessoa2.getName());

        //encapsulamento setNome
        pessoa1.setName("motinha");
        System.out.println("O nome da pessoa é " + pessoa1.getCode() + pessoa1.getName());

    }
 }

